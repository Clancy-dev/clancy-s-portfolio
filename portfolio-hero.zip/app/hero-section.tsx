"use client"

import HeroSection from "./hero-section"

export default function Home() {
  return (
    <main>
      <HeroSection />
    </main>
  )
}
